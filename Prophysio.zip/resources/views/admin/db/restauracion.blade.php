@extends('admin.plantilla_admin')

@section('meta')

@endsection

@section('title', 'Restaurar base de datos')

@section('content')
    <h1>Restore</h1>
@endsection

@section('scripts_styles')

@endsection