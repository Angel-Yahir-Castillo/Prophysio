@extends('admin.plantilla_admin')

@section('meta')

@endsection

@section('title', 'Panel Administrador')

@section('content')
    <h1>panel administrador</h1>
@endsection

@section('scripts_styles')

@endsection