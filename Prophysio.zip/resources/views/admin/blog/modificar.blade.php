@extends('admin.plantilla_admin')

@section('meta')

@endsection

@section('title', 'Modificar')

@section('content')

@endsection

@section('scripts_styles')

@endsection