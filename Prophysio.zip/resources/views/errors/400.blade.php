@extends('errors::prophysioError')

@section('title', 'Solicitud Incorrecta')
@section('code', '400')
@section('message', 'Esta pagina no funciona en este momento')

