@extends('errors::prophysioError')

@section('title', 'Error interno del Servidor')
@section('code', '500')
@section('message', '¡Vaya! Algo salio mal. Trata de volver a cargar esta pagina o no dudes en conctactar con nosotros si el problema persiste')

