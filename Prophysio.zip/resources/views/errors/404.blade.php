@extends('errors::prophysioError')

@section('title', 'Pagina no encontrada')
@section('code', '404')
@section('message', 'Lo sentimos, la pagina solicitada no existe')

