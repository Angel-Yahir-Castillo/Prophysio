@extends('user.plantilla_user')

@section('meta')

@endsection

@section('title', 'Prophysio Huejutla - Terminos y condiciones')

@section('content')
    <div class="container section">
        {{ Breadcrumbs::render('terminos_condiciones') }}
        <h1>Terminos y Condiciones</h1>
    </div>

    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
   
@endsection

@section('scripts_styles')

@endsection



