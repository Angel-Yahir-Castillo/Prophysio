

<?php $__env->startSection('meta'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Prophysio Huejutla - Blog'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container section">
        <div class="row">
            <form id="busquedaA" action="" method="" class="col s12">
                <div class="row">
                    <div class="input-field col s7">
                        <select id="etiquetasLista" name="categoria"> 
                            <option selected value="all">TODOS</option>
                            <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($etiqueta->id); ?>"><?php echo e($etiqueta->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label>Etiquetas</label>
                    </div>
                </div>
            </form>
        </div>
        <div class="row">
        <?php echo e(Breadcrumbs::render('blog')); ?>

        </div>

        <div id="circulo" class="center section hide">
            <div class="preloader-wrapper big active">
                <div class="spinner-layer spinner-blue">
                    <div class="circle-clipper left">
                    <div class="circle"></div>
                    </div><div class="gap-patch">
                    <div class="circle"></div>
                    </div><div class="circle-clipper right">
                    <div class="circle"></div>
                    </div>
                </div>
    
                <div class="spinner-layer spinner-red">
                    <div class="circle-clipper left">
                    <div class="circle"></div>
                    </div><div class="gap-patch">
                    <div class="circle"></div>
                    </div><div class="circle-clipper right">
                    <div class="circle"></div>
                    </div>
                </div>
    
                <div class="spinner-layer spinner-yellow">
                    <div class="circle-clipper left">
                    <div class="circle"></div>
                    </div><div class="gap-patch">
                    <div class="circle"></div>
                    </div><div class="circle-clipper right">
                    <div class="circle"></div>
                    </div>
                </div>
    
                <div class="spinner-layer spinner-green">
                    <div class="circle-clipper left">
                    <div class="circle"></div>
                    </div><div class="gap-patch">
                    <div class="circle"></div>
                    </div><div class="circle-clipper right">
                    <div class="circle"></div>
                    </div>
                </div>
            </div>
        </div>

        <div id="blogs" class="row">
            


        </div>
    </div>

    <style>
        .contBlog{
            transition: all 300ms;
        }
        .contBlog:hover{
            transform: scale(1.10);
        }
        .enlace{
            background-color: white;
            border: 0px;
            color: #FFB219;
        }
        .enlace:hover{
            cursor: pointer;
        }
    </style>
    <script type="" src="<?php echo e(asset('js/blog.js')); ?>"></script>

    <script>
        //obtenerEtiquetas();
        verBlogs();
        
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla_visit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/blog.blade.php ENDPATH**/ ?>