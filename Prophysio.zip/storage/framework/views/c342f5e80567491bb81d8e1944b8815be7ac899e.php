

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Prophysio Huejutla - Preguntas frecuentes'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container section">
        <?php echo e(Breadcrumbs::render('preguntas_frecuentes')); ?>

        <center><h3>Preguntas Frecuentes</h3></center>
        <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="col s12">
                <button class="waves-effect waves-light btn" onclick="ocultarPregunta( '<?php echo e($pregunta->id); ?>' )" style="width: 100%; font-size: 15px"><?php echo e($pregunta->pregunta); ?></button>
            </div>
            <div id="<?php echo e($pregunta->id); ?>" style="display: none;" class="col s12">
                <p class="pregunta"><?php echo e($pregunta->respuesta); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts_styles'); ?>
    <style>
        .pregunta{
            font-size: 23px; 
            padding: 10px;
            border: solid 1px #000;
            background-color: #C7F7F7;
        }
    </style>

    <script>
        function ocultarPregunta(numeroP){
            let pregunta = document.getElementById(numeroP);
            if (pregunta.style.display === "none") {
                pregunta.style.display = "block";
            } else {
                pregunta.style.display = "none";
            }
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('user.plantilla_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/user/preguntas_frecuentes.blade.php ENDPATH**/ ?>