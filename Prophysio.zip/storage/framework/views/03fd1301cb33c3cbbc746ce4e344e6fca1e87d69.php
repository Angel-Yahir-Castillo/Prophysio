

<?php $__env->startSection('title', 'Pagina no encontrada'); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', 'Lo sentimos, la pagina solicitada no existe'); ?>


<?php echo $__env->make('errors::prophysioError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/errors/404.blade.php ENDPATH**/ ?>