

<?php $__env->startSection('title', 'Recuperar Contraseña'); ?>

<?php $__env->startSection('content'); ?>
    
    <br><br><br>
    <div class=" container">
    
        <div class="row section">
        
            <div class="col m2 l3 s0"></div>
            
            <div class="col l6 m8 s12">
                <div class="row card-panel">

                    <center><b>Recuperar Contraseña</b></center>

                    <p> <?php echo e($user->name); ?> hemos enviado tu contraseña a tu correo electronico</p>

                    <center><a class="btn" href="<?php echo e(route('login.visit')); ?>">Aceptar </a></center>

                    <br>

                </div>
            </div>
                
            <div class="col l3 m2 s0"></div>

        </div>

    </div>
    <br><br><br>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla_visit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/recuperar_contrasena_Correo.blade.php ENDPATH**/ ?>