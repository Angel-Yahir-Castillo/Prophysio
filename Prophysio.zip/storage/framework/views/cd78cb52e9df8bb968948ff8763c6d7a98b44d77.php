

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Prophysio Huejutla - Servicios'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container section">
    <?php echo e(Breadcrumbs::render('servicios')); ?>

        <div class="row">
            <center><h3>Nuestros Servicios</h3></center>
            <div class="col s12">
                <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row z-depth-2 section">
                    <center><h5><?php echo e($servicio->nombre); ?></h5></center>
                    <div class=" col s12 m7 l8" style="padding-left: 30px;">                        
                        <?php echo e($servicio->descripcion); ?>

                    </div>
                    <div class="col s12 m5 l4">
                        <center>
                            <img class="responsive-img"  src="<?php echo e(asset('servicios_imagenes/'.$servicio->imagen)); ?>" alt="<?php echo e($servicio->alt); ?>">
                        </center>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts_styles'); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
    
    

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.plantilla_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/user/servicios.blade.php ENDPATH**/ ?>