

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Blogs'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container section row">
        <center><h3>Blogs</h3></center>
        <div class="col s12">
            <table class="striped responsive-table">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Estado</th>
                        <th>Imagen</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($blog->nombre); ?></th>
                            <th><?php echo e($blog->estado); ?></th>
                            <th><img width="200px" height="225px" src="<?php echo e(asset($blog->imagen)); ?>" alt="<?php echo e($blog->alt); ?>"></th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>
        <div class="fixed-action-btn">
            <a href="<?php echo e(route('admin.blog.create')); ?>" class="btn-floating btn-large red">
                <i class="large material-icons">create</i>
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts_styles'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.plantilla_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/admin/blog/mostrar.blade.php ENDPATH**/ ?>