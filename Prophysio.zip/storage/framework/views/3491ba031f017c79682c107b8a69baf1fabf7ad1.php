

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Ver servicios'); ?>

<?php $__env->startSection('content'); ?>

    <div class="section container">
        <center><h3>Servicios</h3></center>
        <div class="col s12">
            <table class="striped responsive-table">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Descripcion</th>
                        <th>Imagen</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($servicio->nombre); ?></th>
                            <th><?php echo e($servicio->descripcion); ?></th>
                            <th><img width="300px" height="225px"  src="<?php echo e(asset('servicios_imagenes/'.$servicio->imagen)); ?>" alt="<?php echo e($servicio->alt); ?>"></th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>
    <div class="fixed-action-btn">
        <a href="<?php echo e(route('admin.servicios.create')); ?>" class="btn-floating btn-large red">
            <i class="large material-icons">create</i>
        </a>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts_styles'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.fixed-action-btn');
            var instances = M.FloatingActionButton.init(elems);
        });
    </script>

    
    <?php if(session('info')): ?>
    <script>
        M.toast({
            html: '<?php echo e(session("info")); ?> ',
            classes: 'black',
            displayLength: 3000,
        })
        //alert("<?php echo e(session('info')); ?>");
    </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.plantilla_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/admin/servicios/mostrar.blade.php ENDPATH**/ ?>