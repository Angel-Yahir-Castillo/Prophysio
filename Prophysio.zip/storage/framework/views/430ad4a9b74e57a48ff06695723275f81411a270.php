

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Panel Terapeuta'); ?>

<?php $__env->startSection('foto', asset('terapeutas/'.$terapeuta->foto)); ?>

<?php $__env->startSection('name', $terapeuta->nombres.' '.$terapeuta->a_paterno.' '.$terapeuta->a_materno); ?>

<?php $__env->startSection('content'); ?>
    <h1>panel Terapeuta</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts_styles'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('terapeuta.plantilla_terapeuta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/terapeuta/dashboard.blade.php ENDPATH**/ ?>