

<?php $__env->startSection('title', 'Autenticacion de doble factor'); ?>

<?php $__env->startSection('content'); ?>
<br><br><br>
    <div class="container section">
        <div class="row card-panel">
            <div class="col s12">
                <strong>Autenticacion de doble factor</strong>
            </div>
            <div class="col s12">
                <p>La autenticación de dos factores (2FA) fortalece la seguridad de acceso al requerir dos métodos (también conocidos como factores) para verificar su identidad. La autenticación de dos factores protege contra el phishing, la ingeniería social y los ataques de fuerza bruta de contraseñas y protege sus inicios de sesión de atacantes que explotan credenciales débiles o robadas.</p>
            </div>
            <div class="col s12">
                <?php if(session('error')): ?>
                    <strong style="color: red;"><?php echo e(session('error')); ?></strong> 
                <?php endif; ?>
            </div>
            <div class="col s12">
                <?php if(session('success')): ?>
                    <strong style="color: #FFAA00;"><?php echo e(session('success')); ?></strong> 
                <?php endif; ?>
            </div>
            <?php if($data['user']->loginSecurity == null): ?>
                <form action="<?php echo e(route('generate2faSecret')); ?>" method="POST" class="col s12">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn">
                        Generar clave secreta para habilitar 2FA
                    </button>
                </form>

            <?php elseif(!$data['user']->loginSecurity->google2fa_enable): ?>
                1. Escanee este código QR con su aplicación Google Authenticator. Alternativamente, puedes usar el código: <code><?php echo e($data['secret']); ?></code><br/>
                <div>
                    <?php echo $data['google2fa_url']; ?>

                </div>
                <!-- <img src="<?php echo e($data['google2fa_url']); ?>" class="responsive-img" alt="QR code"> -->
                <br><br>
                2. Ingrese el pin de la aplicación Google Authenticator:<br><br>
                <form class="row" method="POST" action="<?php echo e(route('enable2fa')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="input-field col s12">
                        <input id="secret" name="secret" type="password" value="" required class="validate" >
                        <label for="secret">Codigo de autenticacion:</label>
                        <?php if($errors->has('verify-code')): ?>
                            <strong style="color: red;"><?php echo e($errors->first('verify-code')); ?></strong> 
                        <?php endif; ?>
                    </div>
                    <div class="col s12">
                        <button type="submit" class="btn">
                            Habilitar 2FA
                        </button>
                    </div>                    
                </form>
            <?php elseif($data['user']->loginSecurity->google2fa_enable): ?>
                <div class="col s12 green-text">
                    2FA está actualmente <strong>habilitada</strong> en su cuenta.
                </div>
                <div class="col s12">
                    <p>Si está buscando deshabilitar la autenticación de dos factores. Confirme su contraseña y haga clic en el botón "Deshabilitar 2FA".</p>
                </div>
                <form class="row" method="POST" action="<?php echo e(route('disable2fa')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="input-field col s12">
                        <input id="current-password" type="password" class="validate" name="current-password" required>
                        <label for="current-password" class="">Contraseña actual:</label>
                            <?php if($errors->has('current-password')): ?>
                                <strong><?php echo e($errors->first('current-password')); ?></strong>
                            <?php endif; ?>
                    </div>
                    <div class="col s12">
                        <button type="submit" class="btn">
                            Deshabilitar 2FA
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.plantilla_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/auth/2fa_settings.blade.php ENDPATH**/ ?>