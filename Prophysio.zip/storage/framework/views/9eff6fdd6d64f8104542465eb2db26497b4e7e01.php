

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Ver Especialidades'); ?>

<?php $__env->startSection('content'); ?>

    <div class="section container">
        <center><h3>Especialidades</h3></center>
        <div class="col s12">
            <table class="striped responsive-table">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Descripcion</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($especialidad->nombre); ?></th>
                            <th><?php echo e($especialidad->descripcion); ?></th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>
    <div class="fixed-action-btn">
        <a href="<?php echo e(route('admin.especialidades.create')); ?>" class="btn-floating btn-large red">
            <i class="large material-icons">create</i>
        </a>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts_styles'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.fixed-action-btn');
            var instances = M.FloatingActionButton.init(elems);
        });
    </script>

    
    <?php if(session('info')): ?>
    <script>
        M.toast({
            html: '<?php echo e(session("info")); ?> ',
            classes: 'black',
            displayLength: 4000,
        })
    </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.plantilla_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/admin/especialidades/mostrar.blade.php ENDPATH**/ ?>