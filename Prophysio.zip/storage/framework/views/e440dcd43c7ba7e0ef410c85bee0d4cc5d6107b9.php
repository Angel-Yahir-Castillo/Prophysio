

<?php $__env->startSection('title', 'Prophysio Huejutla - Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class=" container">


        <div class="row section">
        <?php echo e(Breadcrumbs::render('login')); ?>

            <div class="col m2 l3 s0"></div>
            <form action="<?php echo e(route('inicia.sesion')); ?>" method="POST" class="col l6 m8 s12">
            <?php echo csrf_field(); ?> 
                <div class="row card-panel">

                    <?php if(session('status')): ?>
                        <div class="col s12">
                            <p class="green-text"><?php echo e(session("status")); ?></p> 
                        </div>
                    <?php endif; ?>
                    <center><b>Iniciar sesion</b></center>
                    <small style="color: red;"><?php $__errorArgs = ['g-recaptcha-response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                    <div class="input-field col s12">
                        <input id="correo" name="correo" type="email" value="<?php echo e(old('correo')); ?>" requiered autofocus class="validate" 
                        pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Ingresa un formato de correo electronico valido">
                        <label for="correo">Correo electronico:</label>
                        <small style="color: red;"><?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> 

                    </div>

                    <div class="input-field col s11">
                        <input id="contrasena" name="contrasena" value="<?php echo e(old('contrasena')); ?>" required type="password" class="validate" >
                        <label for="contrasena">Contraseña:</label>
                    </div>
                    <div class="col s1">
                        <button style="background-color: #fff; border:#fff; cursor:pointer;" type="button" onclick="mostrarContrasena()"><i class="material-icons ">remove_red_eye</i></button>
                    </div>
                    <div class="col s12"><small style="color: red;"><?php $__errorArgs = ['contrasena'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> </div>

                    <div class="col s12">
                        <label for="remember_me">
                        <input id="remember_me" name="remember" type="checkbox" class="filled-in">
                            <span>Mantener sesion iniciada</span> 
                        </label>
                    </div>

                    <br>
                    <div class="col s12">
                        <center> ¿Se te olvido tu contraseña?  <a class="" href="<?php echo e(route('password.options')); ?>">Recuperar contraseña </a></center><br>
                    </div>
                    <center><input class="btn" type="submit" value="Iniciar sesion"> </input></center>

                    <br>

                    <center> ¿No tienes una cuenta?  <a class="" href="<?php echo e(route('register.visit')); ?>">Registrarse aqui</a></center>

                </div>
            </form>
        </div>

    </div>
    <br><br><br>

    <script>
        function mostrarContrasena(){
            var tipo = document.getElementById("contrasena");
            if(tipo.type == "password"){
                tipo.type = "text";
            }else{
                tipo.type = "password";
            }
            
        }
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla_visit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/login.blade.php ENDPATH**/ ?>