

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Informacion de la empresa'); ?>

<?php $__env->startSection('content'); ?>

    <div class="section container">
        <center><h3>Informacion de la empresa</h3></center>
        <div class="col s12">
            <table class="striped responsive-table">
                <thead>
                    <tr>
                        <th>Mision</th>
                        <th>Vision</th>
                        <th>Correo</th>
                        <th>Telefono</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th><?php echo e($informacion->mision); ?></th>
                        <th><?php echo e($informacion->vision); ?></th>
                        <th><?php echo e($informacion->email); ?></th>
                        <th><?php echo e($informacion->phone); ?></th>
                    </tr>
                </tbody>

            </table>
        </div>
    </div>
    <div class="fixed-action-btn">
        <a href="<?php echo e(route('admin.empresa.edit')); ?>" class="btn-floating btn-large red">
            <i class="large material-icons">edit</i>
        </a>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts_styles'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.fixed-action-btn');
            var instances = M.FloatingActionButton.init(elems);
        });
    </script>

    
    <?php if(session('info')): ?>
    <script>
        M.toast({
            html: '<?php echo e(session("info")); ?> ',
            classes: 'black',
            displayLength: 4000,
        })
    </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.plantilla_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/admin/informacion_empresa/mostrar.blade.php ENDPATH**/ ?>