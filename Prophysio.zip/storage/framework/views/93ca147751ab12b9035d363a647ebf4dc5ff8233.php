

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Mi cuenta'); ?>

<?php $__env->startSection('content'); ?>
    <center><h3>Hola <?php if(auth()->guard()->check()): ?> <?php echo e(Auth::user()->name); ?> <?php endif; ?></h3></center>


    <div class=" container">
        <div class="row section">
            <div class="col s12">
                <a class="btn" href="<?php echo e(route('configurar.show2faForm')); ?>">
                    Autenticacion de Doble factor
                </a>
            </div>


        </div>
        <div class="row section">
            <form method="POST" class="col s12" action="<?php echo e(route('user.logout')); ?>">
                <?php echo csrf_field(); ?>
                <center><button type="submit" class="btn">
                    Cerrar sesion
                </button></center> 
            </form>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts_styles'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.plantilla_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/user/cuenta.blade.php ENDPATH**/ ?>