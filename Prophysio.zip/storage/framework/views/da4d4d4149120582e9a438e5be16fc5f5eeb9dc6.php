

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Agregar Servicios'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row container section">
            <form action="<?php echo e(route('admin.servicios.store')); ?>" enctype="multipart/form-data" method="POST" class="col s12">

            <?php echo csrf_field(); ?> 
                <div class="row card-panel">

                    <center><b>Agregar un servicio</b></center>
                    <small style="color: red;"><?php $__errorArgs = ['g-recaptcha-response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                    <div class="input-field col s12">
                        <input id="nombre" type="text" value="<?php echo e(old('nombre')); ?>" name="nombre" class="validate" required
                        minlength="5" maxlength="255" title="El nombre debe tener al menos una longitud de 5 letras y maximo 255">
                        <label for="nombre">Nombre:</label>
                        <small style="color: red;"><?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> 
                    </div>
                    
                    <div class="input-field col s12">
                        <input id="descripcion" type="text" value="<?php echo e(old('descripcion')); ?>" name="descripcion" class="validate" required
                        minlength="10" maxlength="255" title="El nombre debe tener al menos una longitud de 10 letras y maximo 255">
                        <label for="descripcion">Descripcion del servicio:</label>
                        <small style="color: red;"><?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> 
                    </div>

                    <div class="file-field input-field col s12">
                        <div class="btn">
                            <span>Imagen</span>
                            <input type="file" required name="imagen" id="imagen" onchange="vistaPreliminar(event)" accept=".jpeg,.jpg,.png" >
                        </div>
                        <div class="file-path-wrapper">
                            <input required class="file-path validate" type="text">
                        </div>
                        <small style="color: red;"><?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> 
                    </div>

                    <div style="display: none" id="div-imagen" class="col s12">
                        <center><img src="" width="300px" height="225px" alt="" id="img-foto"></center>
                    </div>

                    <div class="input-field col s12">
                        <input id="alternativo" type="text" value="<?php echo e(old('alternativo')); ?>" name="alternativo" class="materialize-textarea validate" required
                        minlength="10" maxlength="50" title="El nombre debe tener al menos una longitud de 10 letras y maximo 50">
                        <label for="alternativo">Texto alternativo:</label>
                        <small style="color: red;"><?php $__errorArgs = ['alternativo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> 
                    </div>


                    <center><button class="btn waves-effect waves-light" type="submit" value="">Agregar
                        <i class="material-icons left">
                            create
                        </i>
                    </button></center>

            
                </div>

        </form>
    </div>

    <div class="fixed-action-btn">
        <a href="<?php echo e(route('admin.servicios.show')); ?>" class="btn-floating btn-large red" >
            <i class="large material-icons">arrow_back</i>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts_styles'); ?>

    <script>
        let vistaPreliminar = (event)=>{
            let leer_img = new FileReader();
            let id_img = document.getElementById('img-foto');
            document.getElementById('div-imagen').style.display = 'block';
            leer_img.onload = ()=>{
                if(leer_img.readyState==2){
                    id_img.src = leer_img.result;
                }
            }
            leer_img.readAsDataURL(event.target.files[0])
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.plantilla_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/admin/servicios/crear.blade.php ENDPATH**/ ?>