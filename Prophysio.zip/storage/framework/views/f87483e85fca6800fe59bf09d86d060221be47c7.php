

<?php $__env->startSection('title', 'Prophysio Huejutla - ¿Quines somos?'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container section">
    <?php echo e(Breadcrumbs::render('nosotros')); ?>

        <center><h2>Prophysio Huejutla</h2></center>

        <div class="row">
            <div class="col s12 m6">
                <h4>Mision</h4>
                <p><?php echo e($informacion->mision); ?></p>
            </div>
            <div class="col s12 m6">
                <h4>Vision</h4>
                <p><?php echo e($informacion->vision); ?></p>
            </div>
        </div>


        <div class="row">
            <center><h3>Nuestros especialistas</h3></center>
            <div class="col s12" >

                <!--Aqui inicia plantilla para mostrar terapeutas -->
                <div class="row z-depth-2 section">
                    <div class="col s12 m5 l4">
                        <img class="responsive-img" src="<?php echo e(asset('terapeutas/lizbeth_mendoza.jpeg')); ?>">
            
                    </div>
                    <div class="col s12 m7 l8">
                        <center><b>Lizbeth Mendoza</b></center>
                        <center>Lic. en Fisioterapia</center>
                        <ul>
                            <li>- Diplomado Internacional de Fisioterapia en Oncología</li>
                            <li>- Diplomado de Evaluacion e Intervencion en Desarrollo Motriz</li>
                            <li>- Certificado Internacional en Linfoterapia</li>
                            <li>- Certificado en Terapia Manual Instrumentalizada</li>
                            <li>- Certificacion Internacional DYNAMIC TAPING</li>
                            <li>- Certificacion Internacional Taping Neuro Muscular</li>
                            <li>- Experiencia Clinica y hospitalaria en servicios en reumatología, pediatria y oncologia</li>
                        </ul>
                    </div>
                </div>
                <!-- fin plantilla -->
                
                <div class="row z-depth-2 section"> 
                    <div class="col s12 m5 l4">
                            <img class="responsive-img" src="<?php echo e(asset('terapeutas/lizbeth_mendoza.jpeg')); ?>">
                
                        </div>

                    <div class="col s12 m7 l8">
                        <center><b>Lizbeth Mendoza</b></center>
                        <center>Lic. en Fisioterapia</center>
                        <ul>
                            <li>- Diplomado Internacional de Fisioterapia en Oncología</li>
                            <li>- Diplomado de Evaluacion e Intervencion en Desarrollo Motriz</li>
                            <li>- Certificado Internacional en Linfoterapia</li>
                            <li>- Certificado en Terapia Manual Instrumentalizada</li>
                            <li>- Certificacion Internacional DYNAMIC TAPING</li>
                            <li>- Certificacion Internacional Taping Neuro Muscular</li>
                            <li>- Experiencia Clinica y hospitalaria en servicios en reumatología, pediatria y oncologia</li>
                        </ul>
                    </div>
                </div>

                <div class="row z-depth-2 section"> 
                    <div class="col s12 m5 l4">
                        <img class="responsive-img" src="<?php echo e(asset('terapeutas/lizbeth_mendoza.jpeg')); ?>">
                    </div>

                    <div class="col s12 m7 l8">
                        <center><b>Lizbeth Mendoza</b></center>
                        <center>Lic. en Fisioterapia</center>
                        <ul>
                            <li>- Diplomado Internacional de Fisioterapia en Oncología</li>
                            <li>- Diplomado de Evaluacion e Intervencion en Desarrollo Motriz</li>
                            <li>- Certificado Internacional en Linfoterapia</li>
                            <li>- Certificado en Terapia Manual Instrumentalizada</li>
                            <li>- Certificacion Internacional DYNAMIC TAPING</li>
                            <li>- Certificacion Internacional Taping Neuro Muscular</li>
                            <li>- Experiencia Clinica y hospitalaria en servicios en reumatología, pediatria y oncologia</li>
                        </ul>
                    </div>
                </div>

            </div>

        </div>


    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla_visit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/quienes-somos.blade.php ENDPATH**/ ?>