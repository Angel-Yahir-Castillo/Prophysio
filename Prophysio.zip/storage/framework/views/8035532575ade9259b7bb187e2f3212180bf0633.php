

<?php $__env->startSection('title', 'Prophysio Huejutla - Contacto'); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="section container">
    <?php echo e(Breadcrumbs::render('contacto')); ?>

        <div class="row ">

            <div class="col s0 m1"></div>
            <form action="<?php echo e(route('contacto.enviar')); ?>" method="POST" class="col m10 s12">
            <?php echo csrf_field(); ?>
                <div class="row card-panel">

                    <center><b>Contactanos</b></center>
                    <div class="input-field col s12">
                        <input id="nombre" type="text" value="<?php echo e(old('nombre')); ?>" name="nombre" class="validate" required>
                        <label for="nombre">Nombre completo:</label>
                        <small style="color: red;"><?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> 
                    </div>

                    <div class="input-field col m6 s12">
                        <input id="correo" name="correo" value="<?php echo e(old('correo')); ?>"  type="email" class="validate" required
                        pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Ingresa un correo electronico valido">
                        <label for="correo">Correo electronico:</label>
                        <small style="color: red;"><?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> 
                    </div>

                    <div class="input-field col m6 s12">
                        <input id="telefono" name="telefono" value="<?php echo e(old('telefono')); ?>"  type="tel" class="validate" 
                        pattern="[0-9]{10,10}" title="El telefono debe contener una longitud de 10 digitos" required>
                        <label for="telefono">Telefono:</label>
                        <small style="color: red;"><?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> 
                    </div>



                    <div class="input-field col m12 s12">
                        <textarea id="mensaje" value="<?php echo e(old('mensaje')); ?>"  class="materialize-textarea validate" name="mensaje" required></textarea>
                        <label for="mensaje">Mensaje:</label>
                        <small style="color: red;"><?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> 
                    </div>

                    <center><button class="btn" type="submit" value="">Enviar
                        <i class="material-icons left">
                            send
                        </i>
                    </button></center>

                    <br>

                </div>

                

            </form>
        </div>

        <div class="row">
            <center><h4>Visitanos, nuestra ubicacion:</h4></center>
            <div id="map" class="col s12">

            </div>
        </div>
    </div>

    <script async 
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBnXx_jG0Rev6Hw-tSaQdKLbvFRunowrGU&callback=initMap&v=weekly"
      defer
    ></script>

    <style>
    #map {
        height: 400px; /* The height is 400 pixels */
        width: 100%; /* The width is the width of the web page */
    }
    </style>

    <script>
        // Initialize and add the map
        function initMap() {
        // The location of Uluru
        const prophysio = { lat: 21.143141, lng: -98.422463, };
        // The map, centered at Uluru
        const map = new google.maps.Map(document.getElementById("map"), {
            zoom: 19,
            center: prophysio,
        });
        // The marker, positioned at Uluru
        const marker = new google.maps.Marker({
            position: prophysio,
            map: map,
        });
        }

        window.initMap = initMap;
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    <?php if(session('info')): ?>
        <script>
            M.toast({
                html: '<?php echo e(session("info")); ?> ',
                classes: 'black',
                displayLength: 3000,
            })
            //alert("<?php echo e(session('info')); ?>");
        </script>
    <?php endif; ?>
    <br><br><br>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla_visit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/contacto.blade.php ENDPATH**/ ?>