<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="icon" href="<?php echo e(asset('img/logo.png')); ?>">
    <title>Configuracion de pregunta secreta</title>
</head>
<body>
    <br><br><br>
    

<div class=" container">
    <div class="row section">
    <center><h4>Hola <?php if(auth()->guard()->check()): ?> <?php echo e(Auth::user()->name); ?> <?php endif; ?></h4></center>
    <p><b>Antes de continuar, configura una pregunta secreta, esta te ayudara a recuperar tu contraseña en caso de que la pierdas.</b></p>

        <div class="col m2 l3 s0"></div>
        <form action="<?php echo e(route('user.pregunta.configurar')); ?>" method="POST" class="col l6 m8 s12">
        <?php echo csrf_field(); ?> 
            <div class="row card-panel">

                <?php if(session('status')): ?>
                    <div class="col s12">
                        <p class="red-text"><?php echo e(session("status")); ?></p> 
                    </div>
                <?php endif; ?>
                <center><b>Configurar pregunta secreta</b></center>

                <small style="color: red;"><?php $__errorArgs = ['g-recaptcha-response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>

                <div class="input-field col s12">
                    <select id="pregunta" name="pregunta"> 
                        <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pregunta->id); ?>"><?php echo e($pregunta->pregunta); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label>Elige una Pregunta:</label>
                </div>
                
                <div class="input-field col s12">
                    <input id="respuesta" name="respuesta" type="text" value="<?php echo e(old('respuesta')); ?>" requiered autofocus class="validate">
                    <label for="respuesta">Respuesta:</label>
                    <small style="color: red;"><?php $__errorArgs = ['respuesta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> 

                </div>

                <div class="col s12">
                    <center><button class="btn" type="submit"> Aceptar</button></center>
                </div>

            </div>
        </form>


    </div>
    <div class="row section">
        <form method="POST" class="col s12" action="<?php echo e(route('user.logout')); ?>">
            <?php echo csrf_field(); ?>
            <center><button type="submit" class="btn">
                Cerrar sesion
            </button></center> 
        </form>
    </div>
</div>






    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            M.AutoInit();
        });
    </script>
</body>
</html>


<?php /**PATH C:\Prophysio\resources\views/auth/configurar-pregunta.blade.php ENDPATH**/ ?>