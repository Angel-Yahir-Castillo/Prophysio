

<?php $__env->startSection('title', 'Error interno del Servidor'); ?>
<?php $__env->startSection('code', '500'); ?>
<?php $__env->startSection('message', '¡Vaya! Algo salio mal. Trata de volver a cargar esta pagina o no dudes en conctactar con nosotros si el problema persiste'); ?>

<?php echo $__env->make('errors::prophysioError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/errors/500.blade.php ENDPATH**/ ?>