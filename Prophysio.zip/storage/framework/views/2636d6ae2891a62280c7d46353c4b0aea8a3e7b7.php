

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Copia de seguridad'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row section">
            <div class="col l7 s12">
                <div class="row">
                    <center><h2>Copias de Seguridad</h2></center>
                    <div class="col s12">
                        <h4>Respaldar base de datos de manera completa</h4>
                        <p>
                            Este respaldo guardara un archivo .sql en el dispositivo, este puede ser posteriormente usado para restaurar su base de datos.
                        </p>
                        <center><a href="<?php echo e(route('admin.db.backup.completo')); ?>" class="btn">Respaldo completo </a></center>
                    </div>
                    <form action="<?php echo e(route('admin.db.backup.tabla')); ?>" method="post" class="col s12">
                        <h4>Respaldar una tabla</h4>
                        <p>
                            Se realizara una copia de seguridad unicamente de la tabla seleccionada.
                        </p>
                        <div class="row card-pane">
                            <?php echo csrf_field(); ?>
                            <div class="col s12 input-field">
                                <select name="name_table" id="">
                                    <option value="citas">Citas</option>
                                    <option value="pacientes">Pacientes</option>
                                    <option value="terapeutas">Terapeutas</option>
                                    <option value="servicios">Servicios</option>
                                    <option value="users">Usuarios</option>
                                    <option value="blogs">Articulos</option>
                                    <option value="tags">Etiquetas</option>
                                    <option value="tipo_terapia">Tipos de terapias</option>
                                    <option value="especialidades">Especialidades</option>
                                    <option value="coments">Comentarios</option>
                                    <option value="infomracion_empresa">Informacion de la empresa</option>
                                    <option value="historial_respaldos">Historial de respaldos</option>
                                    <option value="chats">Preguntas chat</option>
                                    <option value="preguntasfrecuentes">Preguntas Frecuentes</option>
                                </select>
                                <label for="name_table">Tabla</label>
                            </div>
                            <center><input class="btn" type="submit" value="Respaldar Tabla"> </input></center>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col l5 s12">
                <center><h3>Historial de respaldos</h3></center>
                <table class="striped responsive-table">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Nombre del respaldo</th>
                            <th>Tipo de respaldo</th>
                            <th>Usuario</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $historial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respaldo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($respaldo->created_at); ?></th>
                                <th><?php echo e($respaldo->nombre_respaldo); ?></th>
                                <th><?php echo e($respaldo->tipo_respaldo); ?></th>
                                <th><?php echo e($respaldo->name); ?></th>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts_styles'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.plantilla_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/admin/db/respaldos.blade.php ENDPATH**/ ?>