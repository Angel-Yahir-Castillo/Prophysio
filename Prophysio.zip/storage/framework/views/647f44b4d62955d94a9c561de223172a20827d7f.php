

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Prophysio Huejutla - Terminos y condiciones'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container section">
        <?php echo e(Breadcrumbs::render('terminos_condiciones')); ?>

        <h1>Terminos y Condiciones</h1>
    </div>

    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts_styles'); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('user.plantilla_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/user/terminos_condiciones.blade.php ENDPATH**/ ?>