

<?php $__env->startSection('title', 'Recuperar Contraseña'); ?>

<?php $__env->startSection('content'); ?>
    
    <br><br><br>
    <div class=" container">
    
        <div class="row section">
        
            <div class="col m2 l3 s0"></div>
            
            <form action="<?php echo e(route('user.recuperarContraseña')); ?>" method="POST" class="col l6 m8 s12">
            <?php echo csrf_field(); ?> 
                <div class="row card-panel">

                    <center><b>Recuperar Contraseña</b></center>

                    <p>Para recuperar su contraseña Ingrese su correo electronico con el cual esta registrado</p>
                    <div class="input-field col s12">
                        <input id="correo" name="correo" type="email" value="<?php echo e(old('correo')); ?>" requiered autofocus class="validate" 
                        pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Ingresa un formato de correo electronico valido">
                        <label for="correo">Correo electronico:</label>
                        <small style="color: red;"><?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> 
                        <small style="color: red;"><?php if(session('info')): ?> <?php echo e(session('info')); ?> <?php endif; ?></small>

                    </div>

                    <center><input class="btn" type="submit" value="Aceptar"> </input></center>

                    <br>

                </div>

                

            </form>
        </div>

    </div>
    <br><br><br>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla_visit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/recuperar_contrasena.blade.php ENDPATH**/ ?>