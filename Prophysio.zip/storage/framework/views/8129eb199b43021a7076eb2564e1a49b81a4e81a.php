

<?php $__env->startSection('title', 'Autenticacion de doble factor'); ?>

<?php $__env->startSection('content'); ?>
<br><br><br>
    <div class="container section">
        <div class="row card-panel">
            <center><strong>Autenticacion de doble factor</strong> </center>
            <div class="col s12">
                <p>La autenticación de dos factores (2FA) fortalece la seguridad de acceso al requerir dos métodos (también conocidos como factores) para verificar su identidad. La autenticación de dos factores protege contra el phishing, la ingeniería social y los ataques de fuerza bruta de contraseñas y protege sus inicios de sesión de atacantes que explotan credenciales débiles o robadas.</p>
            </div>
            <?php if($errors->any()): ?>
                <div class="col s12" style="color: #FFAA00">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            Ingrese el pin de la aplicación Google Authenticator:<br/><br/>
            <form class="row" action="<?php echo e(route('2faVerify')); ?>" method="POST">
            <?php echo csrf_field(); ?>
                <div class="input-field col s12">
                    <input id="one_time_password" name="one_time_password" type="text" value="" required class="validate" >
                    <label for="one_time_password">Contraseña de un solo uso:</label>
                    <?php if($errors->has('verify-code')): ?>
                        <strong style="color: red;"><?php echo e($errors->first('verify-code')); ?></strong> 
                    <?php endif; ?>
                </div>
                <div class="col s12">
                    <button type="submit" class="btn">
                        Autenticar
                    </button>
                </div>   
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.plantilla_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Prophysio\resources\views/auth/2fa_verify.blade.php ENDPATH**/ ?>